package com.inn.cafe.constents;

public class CafeConstants {
    public static final String SOMETHING_WENT_WRONG = "Something Went Wrong.";

    public static final String INVALID_INFO = "Invalid Data.";

    public static final String UNAUTHORIZED_ACCESS = "unauthorized access.";
    public static final String INVALID_DATA = "Invalid Data.";
    public static final String STORE_LOCATION = "F:\\";
    //

}
